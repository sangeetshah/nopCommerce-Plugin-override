﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.MyPlugin
{
    public class MyPluginSettings : ISettings
    {
        public string Message { get; set; }
    }
}
