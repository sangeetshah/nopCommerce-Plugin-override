﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Widgets.MyPlugin;
using Nop.Plugin.Widgets.MyPlugin.Models;
using Nop.Services.Configuration;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Widgets.NivoSlider.Components
{
    [ViewComponent(Name = "WidgetsMyPlugin")]
    public class WidgetsMyPluginViewComponent : NopViewComponent
    {
        private readonly IStoreContext _storeContext;
        private readonly ISettingService _settingService;

        public WidgetsMyPluginViewComponent(
            IStoreContext storeContext,
            ISettingService settingService)
        {
            _storeContext = storeContext;
            _settingService = settingService;
        }

        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            var myPluginSettings = _settingService.LoadSetting<MyPluginSettings>(_storeContext.CurrentStore.Id);
            var model = new ConfigurationModel();
            model.Message = myPluginSettings.Message;

            return View("~/Plugins/Widgets.MyPlugin/Views/Shared/PublicInfo.cshtml", model);
        }
    }
}
