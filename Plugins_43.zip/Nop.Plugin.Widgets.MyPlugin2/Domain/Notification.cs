﻿using Nop.Core;

namespace Nop.Plugin.Widgets.MyPlugin2.Domain
{
    public class Notification : BaseEntity
    {
        public string Name { get; set; }
    }
}
