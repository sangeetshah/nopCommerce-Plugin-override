﻿using Nop.Core;
using Nop.Core.Domain.Cms;
using Nop.Plugin.Widgets.MyPlugin2.Services;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using Nop.Web.Framework.Menu;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Widgets.MyPlugin2
{
    public class MyPlugin : BasePlugin, IWidgetPlugin, IAdminMenuPlugin
    {
        #region Fields

        private readonly ILocalizationService _localizationService;
        private readonly IWebHelper _webHelper;
        private readonly WidgetSettings _widgetSettings;
        private readonly ISettingService _settingService;
        private readonly INotificationService _notificationService;

        #endregion

        #region Ctor

        public MyPlugin(ILocalizationService localizationService,
            IWebHelper webHelper,
            WidgetSettings widgetSettings,
            ISettingService settingService,
            INotificationService notificationService)
        {
            _localizationService = localizationService;
            _webHelper = webHelper;
            _widgetSettings = widgetSettings;
            _settingService = settingService;
            _notificationService = notificationService;
        }

        #endregion

        #region Methods

        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/MyPlugin2/Configure";
        }


        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string> { PublicWidgetZones.HomepageTop };
        }

        /// <summary>
        /// Gets a name of a view component for displaying widget
        /// </summary>
        /// <param name="widgetZone">Name of the widget zone</param>
        /// <returns>View component name</returns>
        public string GetWidgetViewComponentName(string widgetZone)
        {
            return "WidgetsMyPlugin2";
        }

        public override void Install()
        {
            // active this plugin
            _widgetSettings.ActiveWidgetSystemNames.Add(PluginDescriptor.SystemName);
            _settingService.SaveSetting(_widgetSettings);

            _localizationService.AddOrUpdatePluginLocaleResource("Plugin.Widgets.MyCustomPlugin.Message", "Message");
            _localizationService.AddOrUpdatePluginLocaleResource("Plugin.Widgets.MyCustomPlugin.Message.Hint", "Message");
            base.Install();
        }

        public override void Uninstall()
        {
            _localizationService.DeletePluginLocaleResource("Plugin.Widgets.MyCustomPlugin.Message");
            _localizationService.DeletePluginLocaleResource("Plugin.Widgets.MyCustomPlugin.Message.Hint");
            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "Widgets.MyPlugin2",
                Title = "MyPlugin",
                Url = "/Admin/MyPlugin2/Configure",
                Visible = true,
                IconClass= "fa fa-dot-circle-o"                
            };
            var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Third party plugins");
            if (pluginNode != null)
                pluginNode.ChildNodes.Add(menuItem);
            else
                rootNode.ChildNodes.Add(menuItem);
        }

        public bool HideInWidgetList => false;

        #endregion
    }
}
