﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Widgets.MyPlugin2.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;

namespace Nop.Plugin.Widgets.MyPlugin2.Controllers
{
    [Area(AreaNames.Admin)]
    [AutoValidateAntiforgeryToken]
    public class MyPlugin2Controller : BasePluginController
    {

        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;
        private readonly IPermissionService _permissionService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;

        public MyPlugin2Controller(ILocalizationService localizationService,
            INotificationService notificationService,
            IPermissionService permissionService,
            ISettingService settingService,
            IStoreContext storeContext)
        {
            _localizationService = localizationService;
            _notificationService = notificationService;
            _permissionService = permissionService;
            _settingService = settingService;
            _storeContext = storeContext;
        }


        public IActionResult Configure()
        {
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var myPluginSettings = _settingService.LoadSetting<MyPluginSettings2>(storeScope);
            var model = new ConfigurationModel();
            model.Message = myPluginSettings.Message;
            if (storeScope > 0)
            {
                model.Message_OverrideForStore = _settingService.SettingExists(myPluginSettings, x => x.Message, storeScope);
            }


            return View("~/Plugins/Widgets.MyPlugin2/Views/MyPlugin2/Configure.cshtml", model);
        }

        [HttpPost]
        public IActionResult Configure(ConfigurationModel model)
        {
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var myPluginSettings = _settingService.LoadSetting<MyPluginSettings2>(storeScope);
            myPluginSettings.Message = model.Message;
            _settingService.SaveSettingOverridablePerStore(myPluginSettings, x => x.Message, model.Message_OverrideForStore, storeScope, false);
            
            //now clear settings cache
            _settingService.ClearCache();

            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }


    }
}
