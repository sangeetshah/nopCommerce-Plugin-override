﻿using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Controllers;

namespace Nop.Plugin.Widgets.MyPlugin2.Controllers
{
    public class MyPlugin2CommonController : BasePluginController
    {
        public IActionResult ContactUs()
        {
            return View("~/Plugins/Widgets.MyPlugin2/Views/MyPlugin2Common/ContactUs.cshtml");
        }

    }
}
