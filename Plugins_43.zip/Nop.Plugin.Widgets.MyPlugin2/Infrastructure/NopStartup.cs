﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Nop.Core.Infrastructure;
using Nop.Plugin.Widgets.MyPlugin2.Infrastructure;

namespace Nop.Plugin.Widgets.MyPlugin2.Filters
{
    public class NopStartup : INopStartup
    {

        public void Configure(IApplicationBuilder application)
        {
            application.UseSession();
        }

        public void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<RazorViewEngineOptions>(options =>
            {
                options.ViewLocationExpanders.Add(new ViewLocationExpander());
            });

            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => false;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            services.AddScoped<AutoAddRolesFilterAttribute>();

            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(AutoAddRolesFilterAttribute));         // By type
            }).SetCompatibilityVersion(CompatibilityVersion.Version_2_0);

            services.AddDistributedMemoryCache();
            services.AddSession();
            services.AddMvc();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        }

        public int Order
        {
            get { return 1001; } //add after nopcommerce is done
        }

    }
}
