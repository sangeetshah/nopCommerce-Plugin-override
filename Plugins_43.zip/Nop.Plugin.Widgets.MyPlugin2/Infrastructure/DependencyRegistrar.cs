﻿using Autofac;
using Microsoft.AspNetCore.Mvc.Filters;
using Nop.Core.Configuration;
using Nop.Core.Infrastructure;
using Nop.Core.Infrastructure.DependencyManagement;
using Nop.Plugin.Widgets.MyPlugin2.Filters;
using Nop.Plugin.Widgets.MyPlugin2.Services;
using Nop.Services.Customers;

namespace Nop.Plugin.Widgets.MyPlugin2.Infrastructure
{
    /// <summary>
    /// Represents a plugin dependency registrar
    /// </summary>
    public class DependencyRegistrar : IDependencyRegistrar
    {
        /// <summary>
        /// Register services and interfaces
        /// </summary>
        /// <param name="builder">Container builder</param>
        /// <param name="typeFinder">Type finder</param>
        /// <param name="config">Config</param>
        public void Register(ContainerBuilder builder, ITypeFinder typeFinder, NopConfig config)
        {
            builder.RegisterType<NotificationService>().As<INotificationService>().InstancePerLifetimeScope();
            builder.RegisterType<MyPlugIn_CustomerRegistrationService>().As<ICustomerRegistrationService>().InstancePerLifetimeScope();

            // Register our Action Filter
            builder.RegisterType<AutoAddRolesFilterAttribute>().As<IFilterProvider>().InstancePerLifetimeScope();
        }

        /// <summary>
        /// Order of this dependency registrar implementation
        /// </summary>
        public int Order => 2;
    }
}
