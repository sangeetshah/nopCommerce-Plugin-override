﻿using Microsoft.AspNetCore.Mvc.Razor;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.Widgets.MyPlugin2.Infrastructure
{
    public class ViewLocationExpander : IViewLocationExpander
    {
        public void PopulateValues(ViewLocationExpanderContext context)
        {
            //nothing to do here.

        }
        public IEnumerable<string> ExpandViewLocations(ViewLocationExpanderContext context, IEnumerable<string> viewLocations)
        {
            if (context.AreaName == null && context.ViewName == "_ProductBox")
            {
                viewLocations = new string[] { $"/Plugins/Widgets.MyPlugin2/Views/Shared/{{0}}.cshtml" }.Concat(viewLocations);
            }

            return viewLocations;
        }
    }
}
