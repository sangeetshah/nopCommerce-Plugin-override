﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Routing;
using Nop.Data;
using System;
using System.Collections.Generic;

namespace Nop.Plugin.Widgets.MyPlugin2.Filters
{
    public class AutoAddRolesFilterAttribute : ActionFilterAttribute, IFilterProvider
    {
        private readonly IUrlHelperFactory _urlHelperFactory;

        /// <summary>
        /// Constructor
        /// </summary>
        public AutoAddRolesFilterAttribute(IUrlHelperFactory urlHelperFactory)
        {
            _urlHelperFactory = urlHelperFactory;
        }

        /// <summary>
        /// Processes the filter before the controller action is executed
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext == null || filterContext.HttpContext == null)
                return;

            Microsoft.AspNetCore.Http.HttpRequest request = filterContext.HttpContext.Request;
            if (request == null)
                return;

            var actionDescriptor = filterContext.ActionDescriptor as ControllerActionDescriptor;
            string actionName = actionDescriptor?.ActionName;
            if (String.IsNullOrEmpty(actionName))
                return;

            string controllerName = filterContext?.Controller.ToString();
            if (String.IsNullOrEmpty(controllerName))
                return;

            if (!DataSettingsManager.DatabaseIsInstalled)
                return;

            var pluginRegistry= new Dictionary<string, bool>();
            if (controllerName.Equals("Nop.Web.Controllers.CustomerController", StringComparison.InvariantCultureIgnoreCase) &&
                actionName.Equals("Register", StringComparison.InvariantCultureIgnoreCase))
            {
                pluginRegistry["AddressValidation"] = false;
                filterContext.HttpContext.Session.SetString("AddressValidation", pluginRegistry.ToString());
            }

            return;
        }

        public void OnProvidersExecuting(FilterProviderContext context)
        {

        }

        public void OnProvidersExecuted(FilterProviderContext context)
        {

        }
    }
}
