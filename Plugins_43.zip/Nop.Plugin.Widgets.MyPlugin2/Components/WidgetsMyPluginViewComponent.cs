﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Widgets.MyPlugin2;
using Nop.Plugin.Widgets.MyPlugin2.Models;
using Nop.Services.Configuration;
using Nop.Web.Framework.Components;
using Nop.Web.Framework.Themes;

namespace Nop.Plugin.Widgets.NivoSlider.Components
{
    [ViewComponent(Name = "WidgetsMyPlugin2")]
    public class WidgetsMyPlugin2ViewComponent : NopViewComponent
    {
        private readonly IStoreContext _storeContext;
        private readonly ISettingService _settingService;
        private readonly IThemeContext _themeContext;

        public WidgetsMyPlugin2ViewComponent(
            IStoreContext storeContext,
            ISettingService settingService,
            IThemeContext themeContext)
        {
            _storeContext = storeContext;
            _settingService = settingService;
            _themeContext = themeContext;
        }

        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            var myPluginSettings = _settingService.LoadSetting<MyPluginSettings2>(_storeContext.CurrentStore.Id);
            var model = new ConfigurationModel();
            model.Message = myPluginSettings.Message;

            return View("~/Plugins/Widgets.MyPlugin2/Themes/" + _themeContext.WorkingThemeName + "/Views/Shared/PublicInfo.cshtml", model);
        }
    }
}
