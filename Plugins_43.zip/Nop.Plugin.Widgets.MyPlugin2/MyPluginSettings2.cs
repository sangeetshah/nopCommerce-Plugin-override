﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.MyPlugin2
{
    public class MyPluginSettings2 : ISettings
    {
        public string Message { get; set; }
    }
}
