﻿using Nop.Core;
using Nop.Plugin.Widgets.MyPlugin2.Domain;

namespace Nop.Plugin.Widgets.MyPlugin2.Services
{
    public interface INotificationService
    {

        /// <summary>
        /// Search notification
        /// </summary>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <returns>notification</returns>
        IPagedList<Notification> SearchNotification(int pageIndex = 0, int pageSize = int.MaxValue);


        /// <summary>
        /// Insert notification
        /// </summary>
        /// <param name="notification">notification</param>
        void InsertNotification(Notification notification);
    }
}
