﻿using Nop.Core.Domain.Orders;
using Nop.Core.Events;
using Nop.Services.Events;

namespace Nop.Plugin.Widgets.MyPlugin2.Services
{
    public class ShoppingCartItemEntityEvent : IConsumer<EntityInsertedEvent<ShoppingCartItem>>
    {
        public void HandleEvent(EntityInsertedEvent<ShoppingCartItem> eventMessage)
        {
            var shoppingCartItem = eventMessage.Entity as ShoppingCartItem;
        }
    }
}
