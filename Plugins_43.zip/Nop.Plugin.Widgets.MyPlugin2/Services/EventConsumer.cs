﻿using Nop.Core.Domain.Customers;
using Nop.Services.Events;

namespace Nop.Plugin.Widgets.MyPlugin2.Services
{
    public class EventConsumer : IConsumer<CustomerLoggedinEvent>
    {
        public void HandleEvent(CustomerLoggedinEvent eventMessage)
        {
            var customer = eventMessage.Customer;

        }
    }
}
