﻿using Nop.Core;
using Nop.Data;
using Nop.Plugin.Widgets.MyPlugin2.Domain;

namespace Nop.Plugin.Widgets.MyPlugin2.Services
{
    public class NotificationService : INotificationService
    {

        #region Fields

        private readonly IRepository<Notification> _notificationRepository;

        #endregion

        #region Ctor

        public NotificationService(IRepository<Notification> notificationRepository)
        {
            _notificationRepository = notificationRepository;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Search notification
        /// </summary>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <returns>notification</returns>
        public IPagedList<Notification> SearchNotification(int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var query = _notificationRepository.Table;
            return new PagedList<Notification>(query, pageIndex, pageSize);
        }

        /// <summary>
        /// Insert notification
        /// </summary>
        /// <param name="notification">notification</param>

        public void InsertNotification(Notification notification)
        {
            _notificationRepository.Insert(notification);
        }


        #endregion
    }
}
